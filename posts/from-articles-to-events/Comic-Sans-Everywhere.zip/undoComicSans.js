// undoComicSans.js

document.body.style.fontFamily = '';
